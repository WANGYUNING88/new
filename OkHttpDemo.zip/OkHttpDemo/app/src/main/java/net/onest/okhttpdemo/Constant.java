package net.onest.okhttpdemo;

/**
 * Created by zyl on 2018/4/26.
 */

public class Constant {
    public static final String BASE_URL="http://192.168.188.2:8080/OkhttpDemo/";
}
